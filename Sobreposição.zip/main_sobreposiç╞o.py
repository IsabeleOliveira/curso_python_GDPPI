from sobreposição import *

c1 = Cliente('Isabele', 19)
c1.comprar()

print()

c2 = ClienteVIP('Isa', 20, 'Oliveira')
c2.falar()

