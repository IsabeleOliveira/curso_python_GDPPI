from HM_Smartphone import Smartphone

smartphone = Smartphone('Pocophone f1')
smartphone.conectar()
smartphone.desligar()
smartphone.ligar()
smartphone.conectar()
smartphone.conectar()
smartphone.conectar()
smartphone.desligar()
smartphone.conectar()
smartphone.desconectar()
smartphone.desligar()