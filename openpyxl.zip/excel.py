import openpyxl
from random import uniform

"""
planilha_cinema = openpyxl.load_workbook('PLANILHA CINEMA.xlsx')
nome_planilhas = planilha_cinema.sheetnames
planilha1 = planilha_cinema['Planilha1']
planilha1['A2'].value = 2200
planilha_cinema.save('nova_planilha.xlsx')




for campo in planilha1['b']:
    print(campo.value)


for linha in planilha1['a1:c2']:
    for coluna in linha:
        print(coluna.value)



for linha in planilha1:
    for coluna in linha:
        print(coluna.value)
        


for linha in planilha1:
    print(len(linha))



for linha in planilha1:
    if linha[0].value is not None:
        print(linha[0].value, end=" ")
    if linha[1].value is not None:
        print(linha[1].value, end=" ")
    if linha[2].value is not None:
        print(linha[2].value, end=" ")
    
"""

planilha = openpyxl.Workbook()
planilha.create_sheet('Planilha1', 0)
planilha.create_sheet('Planilha2', 1)

planilha1 = planilha['Planilha1']
planilha2 = planilha['Planilha2']

for linha in range(1, 11):
    numero_pedido = linha - 1
    planilha1.cell(linha, 1).value = numero_pedido
    planilha1.cell(linha, 2).value = 1200 + linha


    preco = round(uniform(10, 100), 2)
    planilha1.cell(linha, 3).value = preco


for linha in range(1, 11):
    planilha2.cell(linha, 1).value = f'Isabele{linha} {round(uniform(10, 100), 2)}'
    planilha2.cell(linha, 2).value = f'Maria{linha} {round(uniform( 10, 100 ), 2)}'
    planilha2.cell(linha, 3).value = f'Isa{linha} {round(uniform( 10, 100 ), 2)}'

planilha.save('Planilha.xlsx')
