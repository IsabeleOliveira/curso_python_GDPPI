from Herança_Simples import *

c1 = Cliente('Luiz', 45)
c1.falar()
c1.comprar()

a1 = Aluno('Maria', 20)
a1.falar()
a1.estudar()
